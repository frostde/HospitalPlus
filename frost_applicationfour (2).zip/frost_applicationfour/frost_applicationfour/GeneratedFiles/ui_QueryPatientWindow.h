/********************************************************************************
** Form generated from reading UI file 'QueryPatientWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_QUERYPATIENTWINDOW_H
#define UI_QUERYPATIENTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFormLayout>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_QueryPatientWindow
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QTextBrowser *textBrowser;
    QFormLayout *formLayout;
    QLabel *label;
    QLineEdit *lineEdit;
    QLabel *label_2;
    QLineEdit *lineEdit_2;
    QFrame *line_2;
    QPushButton *pushButton;
    QFrame *line_3;
    QPushButton *pushButton_2;
    QFrame *line_4;

    void setupUi(QWidget *QueryPatientWindow)
    {
        if (QueryPatientWindow->objectName().isEmpty())
            QueryPatientWindow->setObjectName(QStringLiteral("QueryPatientWindow"));
        QueryPatientWindow->resize(497, 499);
        QueryPatientWindow->setStyleSheet(QLatin1String("\n"
"color: white; \n"
"background-color: #151d20;\n"
""));
        widget = new QWidget(QueryPatientWindow);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 0, 481, 491));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        textBrowser = new QTextBrowser(widget);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setStyleSheet(QStringLiteral("border: 0px;"));

        verticalLayout->addWidget(textBrowser);

        formLayout = new QFormLayout();
        formLayout->setSpacing(6);
        formLayout->setObjectName(QStringLiteral("formLayout"));
        label = new QLabel(widget);
        label->setObjectName(QStringLiteral("label"));

        formLayout->setWidget(0, QFormLayout::LabelRole, label);

        lineEdit = new QLineEdit(widget);
        lineEdit->setObjectName(QStringLiteral("lineEdit"));

        formLayout->setWidget(0, QFormLayout::FieldRole, lineEdit);

        label_2 = new QLabel(widget);
        label_2->setObjectName(QStringLiteral("label_2"));

        formLayout->setWidget(1, QFormLayout::LabelRole, label_2);

        lineEdit_2 = new QLineEdit(widget);
        lineEdit_2->setObjectName(QStringLiteral("lineEdit_2"));

        formLayout->setWidget(1, QFormLayout::FieldRole, lineEdit_2);


        verticalLayout->addLayout(formLayout);

        line_2 = new QFrame(widget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);

        pushButton = new QPushButton(widget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(pushButton);

        line_3 = new QFrame(widget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(pushButton_2);

        line_4 = new QFrame(widget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_4);


        retranslateUi(QueryPatientWindow);

        QMetaObject::connectSlotsByName(QueryPatientWindow);
    } // setupUi

    void retranslateUi(QWidget *QueryPatientWindow)
    {
        QueryPatientWindow->setWindowTitle(QApplication::translate("QueryPatientWindow", "QueryPatientWindow", 0));
        label->setText(QApplication::translate("QueryPatientWindow", "First Name:", 0));
        label_2->setText(QApplication::translate("QueryPatientWindow", "Last Name:", 0));
        pushButton->setText(QApplication::translate("QueryPatientWindow", "Query", 0));
        pushButton_2->setText(QApplication::translate("QueryPatientWindow", "Return", 0));
    } // retranslateUi

};

namespace Ui {
    class QueryPatientWindow: public Ui_QueryPatientWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_QUERYPATIENTWINDOW_H
