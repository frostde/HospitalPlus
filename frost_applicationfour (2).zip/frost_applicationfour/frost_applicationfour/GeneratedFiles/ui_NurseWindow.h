/********************************************************************************
** Form generated from reading UI file 'NurseWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_NURSEWINDOW_H
#define UI_NURSEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_NurseWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QFrame *line_4;
    QPushButton *AddPatientButton;
    QFrame *line_3;
    QPushButton *cancelButton;
    QFrame *line_2;

    void setupUi(QWidget *NurseWindow)
    {
        if (NurseWindow->objectName().isEmpty())
            NurseWindow->setObjectName(QStringLiteral("NurseWindow"));
        NurseWindow->setWindowModality(Qt::ApplicationModal);
        NurseWindow->resize(500, 206);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(NurseWindow->sizePolicy().hasHeightForWidth());
        NurseWindow->setSizePolicy(sizePolicy);
        NurseWindow->setMinimumSize(QSize(0, 0));
        NurseWindow->setMaximumSize(QSize(6000, 6000));
        NurseWindow->setStyleSheet(QLatin1String("\n"
"color: black; \n"
"background-color: #151d20;\n"
""));
        layoutWidget = new QWidget(NurseWindow);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(-30, 50, 559, 93));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        line_4 = new QFrame(layoutWidget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_4);

        AddPatientButton = new QPushButton(layoutWidget);
        AddPatientButton->setObjectName(QStringLiteral("AddPatientButton"));
        AddPatientButton->setEnabled(true);
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(AddPatientButton->sizePolicy().hasHeightForWidth());
        AddPatientButton->setSizePolicy(sizePolicy1);
        AddPatientButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout_2->addWidget(AddPatientButton);

        line_3 = new QFrame(layoutWidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_3);

        cancelButton = new QPushButton(layoutWidget);
        cancelButton->setObjectName(QStringLiteral("cancelButton"));
        cancelButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout_2->addWidget(cancelButton);

        line_2 = new QFrame(layoutWidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_2);


        retranslateUi(NurseWindow);

        QMetaObject::connectSlotsByName(NurseWindow);
    } // setupUi

    void retranslateUi(QWidget *NurseWindow)
    {
        NurseWindow->setWindowTitle(QApplication::translate("NurseWindow", "NurseWindow", 0));
        AddPatientButton->setText(QApplication::translate("NurseWindow", "Add Patient", 0));
        cancelButton->setText(QApplication::translate("NurseWindow", "Return", 0));
    } // retranslateUi

};

namespace Ui {
    class NurseWindow: public Ui_NurseWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_NURSEWINDOW_H
