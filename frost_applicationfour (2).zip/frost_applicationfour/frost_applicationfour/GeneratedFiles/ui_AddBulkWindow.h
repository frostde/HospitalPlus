/********************************************************************************
** Form generated from reading UI file 'AddBulkWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDBULKWINDOW_H
#define UI_ADDBULKWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddBulkWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QTextBrowser *PatientBrowser;
    QHBoxLayout *horizontalLayout;
    QFrame *line_2;
    QPushButton *pushButton;
    QFrame *line_3;
    QPushButton *pushButton_2;
    QFrame *line_4;

    void setupUi(QWidget *AddBulkWindow)
    {
        if (AddBulkWindow->objectName().isEmpty())
            AddBulkWindow->setObjectName(QStringLiteral("AddBulkWindow"));
        AddBulkWindow->resize(500, 635);
        AddBulkWindow->setStyleSheet(QLatin1String("\n"
"color: white; \n"
"background-color: #151d20;\n"
""));
        layoutWidget = new QWidget(AddBulkWindow);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(0, 10, 501, 621));
        verticalLayout_2 = new QVBoxLayout(layoutWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        PatientBrowser = new QTextBrowser(layoutWidget);
        PatientBrowser->setObjectName(QStringLiteral("PatientBrowser"));
        PatientBrowser->setStyleSheet(QLatin1String("background-color: #151d20; \n"
"color: white;\n"
"\n"
"border: 0px;"));

        verticalLayout->addWidget(PatientBrowser);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setSpacing(6);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));

        verticalLayout->addLayout(horizontalLayout);


        verticalLayout_2->addLayout(verticalLayout);

        line_2 = new QFrame(layoutWidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_2);

        pushButton = new QPushButton(layoutWidget);
        pushButton->setObjectName(QStringLiteral("pushButton"));
        pushButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout_2->addWidget(pushButton);

        line_3 = new QFrame(layoutWidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_3);

        pushButton_2 = new QPushButton(layoutWidget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout_2->addWidget(pushButton_2);

        line_4 = new QFrame(layoutWidget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_4);


        retranslateUi(AddBulkWindow);

        QMetaObject::connectSlotsByName(AddBulkWindow);
    } // setupUi

    void retranslateUi(QWidget *AddBulkWindow)
    {
        AddBulkWindow->setWindowTitle(QApplication::translate("AddBulkWindow", "AddBulkWindow", 0));
        pushButton->setText(QApplication::translate("AddBulkWindow", "Add Patient in Bulk", 0));
        pushButton_2->setText(QApplication::translate("AddBulkWindow", "Return", 0));
    } // retranslateUi

};

namespace Ui {
    class AddBulkWindow: public Ui_AddBulkWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDBULKWINDOW_H
