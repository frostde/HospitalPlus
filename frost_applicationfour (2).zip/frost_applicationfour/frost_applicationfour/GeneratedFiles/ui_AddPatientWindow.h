/********************************************************************************
** Form generated from reading UI file 'AddPatientWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ADDPATIENTWINDOW_H
#define UI_ADDPATIENTWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_AddPatientWindow
{
public:
    QWidget *layoutWidget;
    QGridLayout *gridLayout_2;
    QLineEdit *middleNameEdit;
    QLabel *label_6;
    QLineEdit *priorityEdit;
    QLabel *label_8;
    QLineEdit *treatedEdit;
    QLabel *label_3;
    QLineEdit *firstNameEdit;
    QLabel *label_4;
    QLabel *label_5;
    QLineEdit *ailmentEdit;
    QLabel *label;
    QLineEdit *lastNameEdit;
    QLineEdit *doctorEdit;
    QLabel *label_7;
    QLineEdit *suffixEdit;
    QLabel *label_2;
    QPushButton *AddAilmentButton;
    QTextBrowser *textBrowser;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QPushButton *AddButton;
    QFrame *line_3;
    QPushButton *cancelButton;
    QFrame *line_4;

    void setupUi(QWidget *AddPatientWindow)
    {
        if (AddPatientWindow->objectName().isEmpty())
            AddPatientWindow->setObjectName(QStringLiteral("AddPatientWindow"));
        AddPatientWindow->setWindowModality(Qt::ApplicationModal);
        AddPatientWindow->resize(505, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(AddPatientWindow->sizePolicy().hasHeightForWidth());
        AddPatientWindow->setSizePolicy(sizePolicy);
        AddPatientWindow->setMinimumSize(QSize(500, 500));
        AddPatientWindow->setAcceptDrops(false);
        AddPatientWindow->setLayoutDirection(Qt::LeftToRight);
        AddPatientWindow->setStyleSheet(QLatin1String("\n"
"color: white; \n"
"background-color: #151d20;\n"
""));
        layoutWidget = new QWidget(AddPatientWindow);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(11, 135, 461, 271));
        gridLayout_2 = new QGridLayout(layoutWidget);
        gridLayout_2->setSpacing(6);
        gridLayout_2->setContentsMargins(11, 11, 11, 11);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        middleNameEdit = new QLineEdit(layoutWidget);
        middleNameEdit->setObjectName(QStringLiteral("middleNameEdit"));
        middleNameEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
""));

        gridLayout_2->addWidget(middleNameEdit, 1, 2, 1, 1);

        label_6 = new QLabel(layoutWidget);
        label_6->setObjectName(QStringLiteral("label_6"));
        label_6->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_6, 5, 0, 1, 1);

        priorityEdit = new QLineEdit(layoutWidget);
        priorityEdit->setObjectName(QStringLiteral("priorityEdit"));
        priorityEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
""));

        gridLayout_2->addWidget(priorityEdit, 7, 2, 1, 1);

        label_8 = new QLabel(layoutWidget);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_8, 7, 0, 1, 1);

        treatedEdit = new QLineEdit(layoutWidget);
        treatedEdit->setObjectName(QStringLiteral("treatedEdit"));
        treatedEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
""));

        gridLayout_2->addWidget(treatedEdit, 6, 2, 1, 1);

        label_3 = new QLabel(layoutWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_3, 2, 0, 1, 1);

        firstNameEdit = new QLineEdit(layoutWidget);
        firstNameEdit->setObjectName(QStringLiteral("firstNameEdit"));
        firstNameEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
"\n"
""));

        gridLayout_2->addWidget(firstNameEdit, 0, 2, 1, 1);

        label_4 = new QLabel(layoutWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_4, 3, 0, 1, 1);

        label_5 = new QLabel(layoutWidget);
        label_5->setObjectName(QStringLiteral("label_5"));
        label_5->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_5, 8, 0, 1, 1);

        ailmentEdit = new QLineEdit(layoutWidget);
        ailmentEdit->setObjectName(QStringLiteral("ailmentEdit"));
        ailmentEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: black;\n"
"border-color: grey;\n"
"\n"
""));

        gridLayout_2->addWidget(ailmentEdit, 8, 2, 1, 1);

        label = new QLabel(layoutWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label, 1, 0, 1, 1);

        lastNameEdit = new QLineEdit(layoutWidget);
        lastNameEdit->setObjectName(QStringLiteral("lastNameEdit"));
        lastNameEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
""));

        gridLayout_2->addWidget(lastNameEdit, 2, 2, 1, 1);

        doctorEdit = new QLineEdit(layoutWidget);
        doctorEdit->setObjectName(QStringLiteral("doctorEdit"));
        doctorEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
""));

        gridLayout_2->addWidget(doctorEdit, 5, 2, 1, 1);

        label_7 = new QLabel(layoutWidget);
        label_7->setObjectName(QStringLiteral("label_7"));
        label_7->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_7, 6, 0, 1, 1);

        suffixEdit = new QLineEdit(layoutWidget);
        suffixEdit->setObjectName(QStringLiteral("suffixEdit"));
        suffixEdit->setStyleSheet(QLatin1String("background-color: white;\n"
"color: grey;\n"
"border-color: grey;\n"
""));

        gridLayout_2->addWidget(suffixEdit, 3, 2, 1, 1);

        label_2 = new QLabel(layoutWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setStyleSheet(QStringLiteral("color: white;"));

        gridLayout_2->addWidget(label_2, 0, 0, 1, 1);

        AddAilmentButton = new QPushButton(AddPatientWindow);
        AddAilmentButton->setObjectName(QStringLiteral("AddAilmentButton"));
        AddAilmentButton->setGeometry(QRect(470, 380, 30, 20));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(AddAilmentButton->sizePolicy().hasHeightForWidth());
        AddAilmentButton->setSizePolicy(sizePolicy1);
        textBrowser = new QTextBrowser(AddPatientWindow);
        textBrowser->setObjectName(QStringLiteral("textBrowser"));
        textBrowser->setGeometry(QRect(0, 0, 510, 91));
        textBrowser->setStyleSheet(QStringLiteral("border: 0px;"));
        widget = new QWidget(AddPatientWindow);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(0, 410, 501, 91));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        AddButton = new QPushButton(widget);
        AddButton->setObjectName(QStringLiteral("AddButton"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(AddButton->sizePolicy().hasHeightForWidth());
        AddButton->setSizePolicy(sizePolicy2);
        AddButton->setLayoutDirection(Qt::LeftToRight);
        AddButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout_2->addWidget(AddButton);

        line_3 = new QFrame(widget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_3);

        cancelButton = new QPushButton(widget);
        cancelButton->setObjectName(QStringLiteral("cancelButton"));
        cancelButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout_2->addWidget(cancelButton);

        line_4 = new QFrame(widget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout_2->addWidget(line_4);


        retranslateUi(AddPatientWindow);

        QMetaObject::connectSlotsByName(AddPatientWindow);
    } // setupUi

    void retranslateUi(QWidget *AddPatientWindow)
    {
        AddPatientWindow->setWindowTitle(QApplication::translate("AddPatientWindow", "AddPatientWindow", 0));
        middleNameEdit->setText(QApplication::translate("AddPatientWindow", "(Middle name of Patient)", 0));
        label_6->setText(QApplication::translate("AddPatientWindow", "Presiding Doctor:", 0));
        priorityEdit->setText(QApplication::translate("AddPatientWindow", "(0-10,000)", 0));
        label_8->setText(QApplication::translate("AddPatientWindow", "Priority Level:", 0));
        treatedEdit->setText(QApplication::translate("AddPatientWindow", "(0 for not treated or 1 for treated)", 0));
        label_3->setText(QApplication::translate("AddPatientWindow", "Last Name:", 0));
        firstNameEdit->setText(QApplication::translate("AddPatientWindow", "(First name of patient)", 0));
        label_4->setText(QApplication::translate("AddPatientWindow", "Suffix:", 0));
        label_5->setText(QApplication::translate("AddPatientWindow", "Ailment:", 0));
        label->setText(QApplication::translate("AddPatientWindow", "Middle Name:", 0));
        lastNameEdit->setText(QApplication::translate("AddPatientWindow", "(Last name of Patient)", 0));
        doctorEdit->setText(QApplication::translate("AddPatientWindow", "(Last Name of doctor)", 0));
        label_7->setText(QApplication::translate("AddPatientWindow", "Treated:", 0));
        suffixEdit->setText(QApplication::translate("AddPatientWindow", "(Suffix of patient)", 0));
        label_2->setText(QApplication::translate("AddPatientWindow", "First Name:", 0));
        AddAilmentButton->setText(QApplication::translate("AddPatientWindow", "+", 0));
        textBrowser->setHtml(QApplication::translate("AddPatientWindow", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0//EN\" \"http://www.w3.org/TR/REC-html40/strict.dtd\">\n"
"<html><head><meta name=\"qrichtext\" content=\"1\" /><style type=\"text/css\">\n"
"p, li { white-space: pre-wrap; }\n"
"</style></head><body style=\" font-family:'MS Shell Dlg 2'; font-size:8pt; font-weight:400; font-style:normal;\">\n"
"<p style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">Please enter the information associated with the patient you wish to add.  Make sure to fill out as many fields as possible.  To add ailments, please click the + icon to the right of the field. Proceed to click &quot;Add&quot; once finished, or return to cancel.</p></body></html>", 0));
        AddButton->setText(QApplication::translate("AddPatientWindow", "Add", 0));
        cancelButton->setText(QApplication::translate("AddPatientWindow", "Return", 0));
    } // retranslateUi

};

namespace Ui {
    class AddPatientWindow: public Ui_AddPatientWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ADDPATIENTWINDOW_H
