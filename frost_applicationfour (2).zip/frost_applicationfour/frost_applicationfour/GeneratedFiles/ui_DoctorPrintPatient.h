/********************************************************************************
** Form generated from reading UI file 'DoctorPrintPatient.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DOCTORPRINTPATIENT_H
#define UI_DOCTORPRINTPATIENT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QTextBrowser>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_DoctorPrintPatient
{
public:
    QWidget *widget;
    QVBoxLayout *verticalLayout;
    QTextBrowser *PatientBrowser;
    QFrame *line_5;
    QPushButton *PrintAllButton;
    QFrame *line_6;
    QPushButton *NextPatientButton;
    QFrame *line_7;
    QPushButton *pushButton_2;
    QFrame *line_8;

    void setupUi(QWidget *DoctorPrintPatient)
    {
        if (DoctorPrintPatient->objectName().isEmpty())
            DoctorPrintPatient->setObjectName(QStringLiteral("DoctorPrintPatient"));
        DoctorPrintPatient->resize(500, 635);
        DoctorPrintPatient->setStyleSheet(QLatin1String("\n"
"color: white; \n"
"background-color: #151d20;\n"
""));
        widget = new QWidget(DoctorPrintPatient);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setGeometry(QRect(10, 10, 491, 611));
        verticalLayout = new QVBoxLayout(widget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        PatientBrowser = new QTextBrowser(widget);
        PatientBrowser->setObjectName(QStringLiteral("PatientBrowser"));
        PatientBrowser->setStyleSheet(QLatin1String("background-color: #151d20; \n"
"color: white;"));

        verticalLayout->addWidget(PatientBrowser);

        line_5 = new QFrame(widget);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_5);

        PrintAllButton = new QPushButton(widget);
        PrintAllButton->setObjectName(QStringLiteral("PrintAllButton"));
        PrintAllButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(PrintAllButton);

        line_6 = new QFrame(widget);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_6);

        NextPatientButton = new QPushButton(widget);
        NextPatientButton->setObjectName(QStringLiteral("NextPatientButton"));
        NextPatientButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(NextPatientButton);

        line_7 = new QFrame(widget);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_7);

        pushButton_2 = new QPushButton(widget);
        pushButton_2->setObjectName(QStringLiteral("pushButton_2"));
        pushButton_2->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(pushButton_2);

        line_8 = new QFrame(widget);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_8);


        retranslateUi(DoctorPrintPatient);

        QMetaObject::connectSlotsByName(DoctorPrintPatient);
    } // setupUi

    void retranslateUi(QWidget *DoctorPrintPatient)
    {
        DoctorPrintPatient->setWindowTitle(QApplication::translate("DoctorPrintPatient", "DoctorPrintPatient", 0));
        PrintAllButton->setText(QApplication::translate("DoctorPrintPatient", "Print Treated", 0));
        NextPatientButton->setText(QApplication::translate("DoctorPrintPatient", "Next Patient", 0));
        pushButton_2->setText(QApplication::translate("DoctorPrintPatient", "Cancel", 0));
    } // retranslateUi

};

namespace Ui {
    class DoctorPrintPatient: public Ui_DoctorPrintPatient {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DOCTORPRINTPATIENT_H
