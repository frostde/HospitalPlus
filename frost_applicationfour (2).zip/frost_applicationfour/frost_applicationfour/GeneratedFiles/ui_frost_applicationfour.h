/********************************************************************************
** Form generated from reading UI file 'frost_applicationfour.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_FROST_APPLICATIONFOUR_H
#define UI_FROST_APPLICATIONFOUR_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_frost_applicationfourClass
{
public:
    QWidget *centralWidget;
    QLabel *label;
    QLabel *label_2;
    QLabel *label_3;
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QFrame *line_8;
    QPushButton *NurseButton;
    QFrame *line_3;
    QPushButton *DoctorButton;
    QFrame *line_4;
    QPushButton *HospitalButton;
    QFrame *line_5;
    QPushButton *AdministratorButton;
    QFrame *line_6;
    QPushButton *HelpButton;
    QFrame *line_7;
    QFrame *line_2;
    QLabel *label_4;
    QMenuBar *menuBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *frost_applicationfourClass)
    {
        if (frost_applicationfourClass->objectName().isEmpty())
            frost_applicationfourClass->setObjectName(QStringLiteral("frost_applicationfourClass"));
        frost_applicationfourClass->setWindowModality(Qt::ApplicationModal);
        frost_applicationfourClass->resize(500, 500);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Maximum);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(frost_applicationfourClass->sizePolicy().hasHeightForWidth());
        frost_applicationfourClass->setSizePolicy(sizePolicy);
        frost_applicationfourClass->setMinimumSize(QSize(500, 500));
        frost_applicationfourClass->setMaximumSize(QSize(500, 500));
        frost_applicationfourClass->setStyleSheet(QLatin1String("\n"
"color: black; \n"
"background-color: #151d20;\n"
""));
        centralWidget = new QWidget(frost_applicationfourClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        label = new QLabel(centralWidget);
        label->setObjectName(QStringLiteral("label"));
        label->setGeometry(QRect(170, 130, 181, 31));
        QSizePolicy sizePolicy1(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy1);
        label->setStyleSheet(QLatin1String("color: white;\n"
"button-layout: 2; font-size: 25px; text-align: relative;"));
        label->setAlignment(Qt::AlignCenter);
        label_2 = new QLabel(centralWidget);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setGeometry(QRect(120, 170, 271, 20));
        sizePolicy1.setHeightForWidth(label_2->sizePolicy().hasHeightForWidth());
        label_2->setSizePolicy(sizePolicy1);
        label_2->setStyleSheet(QStringLiteral("color: #028ec3; font-size: 16px;"));
        label_2->setAlignment(Qt::AlignCenter);
        label_3 = new QLabel(centralWidget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setGeometry(QRect(210, 30, 101, 91));
        label_3->setStyleSheet(QLatin1String("background-image: url(\"C:/Users/frost/OneDrive/Documents/Visual Studio 2015/Projects/frost_applicationfour/frost_applicationfour/Resources/Images/steth.jpg\");\n"
"border: 1px;\n"
"border-radius: 45px;"));
        layoutWidget = new QWidget(centralWidget);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(-10, 230, 531, 191));
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(0);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setSizeConstraint(QLayout::SetDefaultConstraint);
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        line_8 = new QFrame(layoutWidget);
        line_8->setObjectName(QStringLiteral("line_8"));
        line_8->setFrameShape(QFrame::HLine);
        line_8->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_8);

        NurseButton = new QPushButton(layoutWidget);
        NurseButton->setObjectName(QStringLiteral("NurseButton"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(NurseButton->sizePolicy().hasHeightForWidth());
        NurseButton->setSizePolicy(sizePolicy2);
        NurseButton->setContextMenuPolicy(Qt::ActionsContextMenu);
        NurseButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(NurseButton);

        line_3 = new QFrame(layoutWidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        DoctorButton = new QPushButton(layoutWidget);
        DoctorButton->setObjectName(QStringLiteral("DoctorButton"));
        DoctorButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(DoctorButton);

        line_4 = new QFrame(layoutWidget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_4);

        HospitalButton = new QPushButton(layoutWidget);
        HospitalButton->setObjectName(QStringLiteral("HospitalButton"));
        HospitalButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(HospitalButton);

        line_5 = new QFrame(layoutWidget);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_5);

        AdministratorButton = new QPushButton(layoutWidget);
        AdministratorButton->setObjectName(QStringLiteral("AdministratorButton"));
        AdministratorButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(AdministratorButton);

        line_6 = new QFrame(layoutWidget);
        line_6->setObjectName(QStringLiteral("line_6"));
        line_6->setFrameShape(QFrame::HLine);
        line_6->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_6);

        HelpButton = new QPushButton(layoutWidget);
        HelpButton->setObjectName(QStringLiteral("HelpButton"));
        HelpButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(HelpButton);

        line_7 = new QFrame(layoutWidget);
        line_7->setObjectName(QStringLiteral("line_7"));
        line_7->setFrameShape(QFrame::HLine);
        line_7->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_7);

        line_2 = new QFrame(centralWidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setGeometry(QRect(-20, 10, 641, 16));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);
        label_4 = new QLabel(centralWidget);
        label_4->setObjectName(QStringLiteral("label_4"));
        label_4->setGeometry(QRect(200, 190, 140, 20));
        label_4->setStyleSheet(QStringLiteral("color: #028ec3; font-size: 16px;"));
        frost_applicationfourClass->setCentralWidget(centralWidget);
        layoutWidget->raise();
        label->raise();
        label_2->raise();
        label_3->raise();
        line_2->raise();
        label_4->raise();
        menuBar = new QMenuBar(frost_applicationfourClass);
        menuBar->setObjectName(QStringLiteral("menuBar"));
        menuBar->setGeometry(QRect(0, 0, 500, 31));
        frost_applicationfourClass->setMenuBar(menuBar);
        statusBar = new QStatusBar(frost_applicationfourClass);
        statusBar->setObjectName(QStringLiteral("statusBar"));
        frost_applicationfourClass->setStatusBar(statusBar);

        retranslateUi(frost_applicationfourClass);

        QMetaObject::connectSlotsByName(frost_applicationfourClass);
    } // setupUi

    void retranslateUi(QMainWindow *frost_applicationfourClass)
    {
        frost_applicationfourClass->setWindowTitle(QApplication::translate("frost_applicationfourClass", "Frost's Hospital Application", 0));
        label->setText(QApplication::translate("frost_applicationfourClass", "HospitalPlus", 0));
        label_2->setText(QApplication::translate("frost_applicationfourClass", "A patient management system", 0));
        label_3->setText(QString());
        NurseButton->setText(QApplication::translate("frost_applicationfourClass", "Nurse", 0));
        DoctorButton->setText(QApplication::translate("frost_applicationfourClass", "Doctor", 0));
        HospitalButton->setText(QApplication::translate("frost_applicationfourClass", "Hospital Staff", 0));
        AdministratorButton->setText(QApplication::translate("frost_applicationfourClass", "Administrator", 0));
        HelpButton->setText(QApplication::translate("frost_applicationfourClass", "Help", 0));
        label_4->setText(QApplication::translate("frost_applicationfourClass", "By Daniel Frost", 0));
    } // retranslateUi

};

namespace Ui {
    class frost_applicationfourClass: public Ui_frost_applicationfourClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_FROST_APPLICATIONFOUR_H
