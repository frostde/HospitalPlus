/********************************************************************************
** Form generated from reading UI file 'HospitalWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.7.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOSPITALWINDOW_H
#define UI_HOSPITALWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HospitalWindow
{
public:
    QWidget *layoutWidget;
    QVBoxLayout *verticalLayout;
    QFrame *line_2;
    QPushButton *printTriageButton;
    QFrame *line_3;
    QPushButton *treatAllPatientsButton;
    QFrame *line_4;
    QPushButton *cancelbutton;
    QFrame *line_5;
    QProgressBar *progressBar;

    void setupUi(QWidget *HospitalWindow)
    {
        if (HospitalWindow->objectName().isEmpty())
            HospitalWindow->setObjectName(QStringLiteral("HospitalWindow"));
        HospitalWindow->resize(500, 220);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(HospitalWindow->sizePolicy().hasHeightForWidth());
        HospitalWindow->setSizePolicy(sizePolicy);
        HospitalWindow->setStyleSheet(QLatin1String("\n"
"color: white; \n"
"background-color: #151d20;\n"
""));
        layoutWidget = new QWidget(HospitalWindow);
        layoutWidget->setObjectName(QStringLiteral("layoutWidget"));
        layoutWidget->setGeometry(QRect(-40, 30, 591, 137));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(layoutWidget->sizePolicy().hasHeightForWidth());
        layoutWidget->setSizePolicy(sizePolicy1);
        verticalLayout = new QVBoxLayout(layoutWidget);
        verticalLayout->setSpacing(6);
        verticalLayout->setContentsMargins(11, 11, 11, 11);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        line_2 = new QFrame(layoutWidget);
        line_2->setObjectName(QStringLiteral("line_2"));
        line_2->setFrameShape(QFrame::HLine);
        line_2->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_2);

        printTriageButton = new QPushButton(layoutWidget);
        printTriageButton->setObjectName(QStringLiteral("printTriageButton"));
        QSizePolicy sizePolicy2(QSizePolicy::Minimum, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(printTriageButton->sizePolicy().hasHeightForWidth());
        printTriageButton->setSizePolicy(sizePolicy2);
        printTriageButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(printTriageButton);

        line_3 = new QFrame(layoutWidget);
        line_3->setObjectName(QStringLiteral("line_3"));
        line_3->setFrameShape(QFrame::HLine);
        line_3->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_3);

        treatAllPatientsButton = new QPushButton(layoutWidget);
        treatAllPatientsButton->setObjectName(QStringLiteral("treatAllPatientsButton"));
        sizePolicy2.setHeightForWidth(treatAllPatientsButton->sizePolicy().hasHeightForWidth());
        treatAllPatientsButton->setSizePolicy(sizePolicy2);
        treatAllPatientsButton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(treatAllPatientsButton);

        line_4 = new QFrame(layoutWidget);
        line_4->setObjectName(QStringLiteral("line_4"));
        line_4->setFrameShape(QFrame::HLine);
        line_4->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_4);

        cancelbutton = new QPushButton(layoutWidget);
        cancelbutton->setObjectName(QStringLiteral("cancelbutton"));
        sizePolicy2.setHeightForWidth(cancelbutton->sizePolicy().hasHeightForWidth());
        cancelbutton->setSizePolicy(sizePolicy2);
        cancelbutton->setStyleSheet(QLatin1String("QPushButton:hover {\n"
"background-color: #0c1416;\n"
"color: white;\n"
"font-size: 19px;\n"
"bottom-margin: 0px;\n"
"}\n"
"\n"
"QPushButton {\n"
"background-color: #151d20;\n"
"font-size: 19px;\n"
"color: #657980;\n"
"border: 1px red;\n"
"}\n"
""));

        verticalLayout->addWidget(cancelbutton);

        line_5 = new QFrame(layoutWidget);
        line_5->setObjectName(QStringLiteral("line_5"));
        line_5->setFrameShape(QFrame::HLine);
        line_5->setFrameShadow(QFrame::Sunken);

        verticalLayout->addWidget(line_5);

        progressBar = new QProgressBar(HospitalWindow);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        progressBar->setGeometry(QRect(10, 180, 481, 21));
        sizePolicy.setHeightForWidth(progressBar->sizePolicy().hasHeightForWidth());
        progressBar->setSizePolicy(sizePolicy);
        progressBar->setStyleSheet(QLatin1String("QProgressBar:horizontal {\n"
"border: 1px solid gray;\n"
"border-radius: 3px;\n"
"background: white;\n"
"padding: 1px;\n"
"}\n"
"QProgressBar::chunk:horizontal {\n"
"background: qlineargradient(x1: 0, y1: 0.5, x2: 1, y2: 0.5, stop: 0 green, stop: 1 white);\n"
"}"));
        progressBar->setValue(0);

        retranslateUi(HospitalWindow);

        QMetaObject::connectSlotsByName(HospitalWindow);
    } // setupUi

    void retranslateUi(QWidget *HospitalWindow)
    {
        HospitalWindow->setWindowTitle(QApplication::translate("HospitalWindow", "HospitalWindow", 0));
        printTriageButton->setText(QApplication::translate("HospitalWindow", "Print Patients", 0));
        treatAllPatientsButton->setText(QApplication::translate("HospitalWindow", "Treat All Patients", 0));
        cancelbutton->setText(QApplication::translate("HospitalWindow", "Return", 0));
    } // retranslateUi

};

namespace Ui {
    class HospitalWindow: public Ui_HospitalWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOSPITALWINDOW_H
