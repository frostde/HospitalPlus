#include "frost_applicationfour.h"



PatientListClass::PatientListClass()
{
}


PatientListClass::~PatientListClass()
{
}
