#pragma once
#include "frost_applicationfour.h"
#include <queue>

class PatientListClass
{

public:
	
	PatientListClass();
	~PatientListClass();
};

